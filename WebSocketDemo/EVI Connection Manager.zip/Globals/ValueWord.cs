﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebSocketServer.Globals
{
	public class ValueWord
	{
		public const string EVENT_UPDATE = "update";
	}
}
