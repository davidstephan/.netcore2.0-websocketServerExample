﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebSocketServer.Globals;
using WebSocketServer.WebSockets;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Schema;

namespace WebSocketServer.Controllers
{
	[Produces("application/json")]
	[Route("webapi/update")]
	public class UpdateController : Controller
	{
		private EviWebSocketHandler clientWebSocketHandler { get; set; }

		public UpdateController(EviWebSocketHandler handler)
		{
			clientWebSocketHandler = handler;
		}
		// GET webapi/update
		[HttpGet]
		public ActionResult Test()
		{
			return Content(GetAllEntities.GetTheList(), "application/json");
		}
	}
}
