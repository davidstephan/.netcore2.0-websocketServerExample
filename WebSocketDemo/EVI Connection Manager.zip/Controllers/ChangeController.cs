﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebSocketServer.Globals;
using WebSocketServer.WebSockets;
using Newtonsoft.Json;

namespace WebSocketServer.Controllers
{
	[Produces("application/json")]
	[Route("webapi/Change")]
	public class ChangeController : Controller
	{
		private EviWebSocketHandler clientWebSocketHandler { get; set; }

		public ChangeController(EviWebSocketHandler handler)
		{
			clientWebSocketHandler = handler;
		}

		// GET: webapi/Change
		[HttpGet]
		public ActionResult Get()
		{
			return Content(GetAllEntities.GetTheList(), "application/json");
		}


		[HttpPost]
		public IActionResult Post([FromBody] Entity entity)
		{
			Debug.WriteLine("");
			Debug.WriteLine("Debug: This just arrived as Post from /webapi/change:");
			entity.PrintToConsole();
			
			return Json(entity);


		}
	}

}